# Corewell Infra Developers website

Static website: no build step. Upload this whole folder to any static host (Netlify, Cloudflare Pages, Vercel).

## Lead form -> Supabase
- The form saves to the `public.leads` table with the official `@supabase/supabase-js` client (v2.117.2).
- The browser bundle is kept in `vendor/supabase-js-2.117.2.umd.js` (installed with `npm install @supabase/supabase-js@2.117.2`).
- Project URL and PUBLISHABLE key are set in `index.html` (search for `SUPABASE_URL`). The publishable key is made for browsers and is not a secret.
- NEVER put a secret key or a `service_role` key in this folder or in Git.
- Columns written: `full_name`, `phone`, `location`. `id` and `created_at` come from the database.

## Test locally
Run `python3 -m http.server 8000` in this folder, open http://localhost:8000, submit the quote form, then check Supabase > Table Editor > leads.

## Update the library later
`npm install @supabase/supabase-js@<version>` then copy `node_modules/@supabase/supabase-js/dist/umd/supabase.js` to `vendor/` and update the filename in `index.html`.

## If the form says "Sorry, we could not send your details"
Open the site with `?debug=1` on the end (for example `https://yoursite.com/?debug=1`), submit again, and read the grey text under the form. It shows the real Supabase error. Common ones:
- `42501 permission denied for table leads` -> run `grant insert on public.leads to anon;` in the Supabase SQL Editor.
- `42501 new row violates row-level security policy` -> the INSERT policy does not allow the `anon` role.
- `PGRST204 Could not find the 'full_name' column` -> the table column names do not match.
- `Invalid API key` -> check the publishable key.
- `Failed to fetch` -> the browser could not reach Supabase (blocked network or ad blocker).
